module.exports = {
  content: ['**/*.{html,js}', '../src/abella_doc.ml'],
  theme: {
    extend: {
      fontFamily: {
        mysans: ['Liberation Sans', 'sans-serif']
      }
    },
  },
  plugins: [],
}
