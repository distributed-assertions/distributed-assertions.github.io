(* This file is generated. Do not edit! *)
(* dune exec ../gen/damf_cids.ml -- -o damf_cids.ml *)
let language_cid = "bafyreiga2dpaxobxqvvy2akl2frrap2xzw5xrq2olpfnv5q5e362vaua5q";;
let tool_cid = "bafyreiehnznomgmy3u724hk4jhhkvsnwgoavyva5kbxoeqfhl5epn6ev6a";;
